/**
 * Example panel plugin.
 *
 *   node dist/cli.js --plugins examples/plugins
 *
 * A plugin is any CommonJS module exporting an object with:
 *   id          lowercase single word, unique
 *   title       two words, Title Case
 *   intervalMs  how often sample() is called
 *   sample      (now) => PanelData | Promise<PanelData>
 *
 * Keep the output to four short lines; the panel body clips at the box width.
 */
module.exports = {
  id: 'weather',
  title: 'Weather Radar',
  intervalMs: 30000,
  sample(now) {
    return {
      id: 'weather',
      title: 'Weather Radar',
      state: 'nominal',
      updatedAt: now,
      whisper: 'the rain is coming from the east',
      lines: ['rain   in 20m', 'wind   4 m/s NE', 'temp   12C', 'fog    over the graveyard'],
    };
  },
};
