# ANSI style steering

Rules every panel and effect must follow. They exist because a haunted look falls
apart the moment two panels disagree about what "dim" means.

## Palette

Use `PALETTE` from `src/render/ansi.ts` and nothing else:

| token | use |
|---|---|
| `phosphor` | live values, nominal state |
| `phosphorDim` | borders that are flickering, headers |
| `ghost` | burn-in afterimages, whisper lines |
| `bone` | panel titles |
| `candle` | watch state |
| `blood` | alarm state |
| `ash` | idle state, footer hints |

Never hard-code a 256-colour index outside `ansi.ts`. Never use truecolour.

## Layout discipline

- One code point is one cell. Full-width characters and emoji are out of scope;
  they break the geometry arithmetic that the property tests verify.
- Write through `writeText`, never by touching `screen.cells` directly, so clipping
  and bounds checks stay in one place.
- Panels draw a single-line box; body text starts at `rect.x + 2` and is clipped to
  `rect.w - 4`.

## Effects discipline

- Effects are pure functions of `(now, config)`. No `Math.random()` at render time;
  seeds live in `effects/flicker.ts`.
- Flicker may dim borders and titles only. Body cells are sacred (requirement R3).
- Ghosts paint before boxes, never after.

## Naming

Panel ids are lowercase single words (`system`, `git`, `ci`, `moon`). Titles are
two words in Title Case. Whisper lines are lowercase and never end with a period.
