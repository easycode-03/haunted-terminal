# Panel Grid - Tasks

- [x] 1. Scaffold the TypeScript project, tsconfig and scripts
- [x] 2. Cell buffer and drawing primitives (`render/screen.ts`)
- [x] 3. ANSI palette and escape control (`render/ansi.ts`)
- [x] 4. Pure geometry with minimum panel sizes (`render/layout.ts`)
- [x] 5. Frame diff: `changes`, `applyChanges`, `serialize`
- [x] 6. Deterministic flicker schedule with the 120ms / 700ms invariants
- [x] 7. Burn-in ghost layer with 900ms decay
- [x] 8. Typewriter reveal and whisper channel
- [x] 9. Pure frame composition (`render/frame.ts`)
- [x] 10. Render loop: scheduling, resize, keys, frame statistics
- [x] 11. Panel adapters: system, git, ci fixture, moon phase
- [x] 12. CLI: `--plain`, `--fps`, `--once`, `--stats`, `--width`, `--height`
- [x] 13. Property tests: layout bounds, non-overlap, diff round-trip, flicker cap,
       value persistence under flicker
- [ ] 14. Replace the CI fixture with a live GitHub Actions adapter (MCP server)
- [ ] 15. Theme packs and a plugin API for third-party panels
- [ ] 16. Web mirror through xterm.js for browser-only viewers
