# Panel Grid - Requirements

Spec for the Haunted Terminal dashboard grid. Written before any renderer code
existed, and kept as the source of truth during implementation.

## R1 - Live panel grid

The dashboard SHALL render four data panels (System Metrics, Git Status, CI
Pipeline, Moon Phase) inside one terminal frame, refreshing each panel on its own
cadence without blocking the render loop.

## R2 - Layout holds at any terminal geometry

WHEN the terminal is between 40 and 300 columns wide and between 12 and 60 rows
tall, the layout SHALL produce panel rects that

- stay inside the drawable area (above the footer line, below the masthead),
- never overlap each other,
- never be zero-sized,
- use a 2x2 grid whenever the geometry allows it, and fall back to a pageable
  single row otherwise.

## R3 - Flicker never hides a value

WHILE the flicker effect is active, any value rendered in a panel SHALL stay
readable. Concretely:

- a single hidden stretch SHALL never exceed 120ms,
- consecutive hidden stretches SHALL be separated by at least 700ms,
- the flicker SHALL only ever affect borders and titles, never body cells.

## R4 - Frame-diff redraw

The renderer SHALL compute the difference between the previous and the next
frame and emit only the changed SGR runs. Applying the emitted changes to the
previous frame SHALL reproduce the next frame exactly.

## R5 - Decay, not erasure

WHEN a bright character disappears from the screen, its afterimage SHALL fade out
within 900ms and SHALL never overwrite live content.

## R6 - Determinism

Every effect (flicker, typewriter, whisper, moon phase) SHALL be a pure function
of time and configuration, so the dashboard can be screenshotted and tested
without flake.

## R7 - Plain mode

WHEN `--plain` is passed, all atmosphere SHALL be removed and the frame SHALL
render as monochrome text that survives a pipe into a log file.
