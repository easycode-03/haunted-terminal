# Panel Grid - Design

## Layers

```
cli.ts            arg parsing, entry point, headless single-frame mode
  render/loop.ts  clock, panel scheduling, resize, keys, frame statistics
    render/frame.ts         pure composition: FrameInput -> Screen
      render/layout.ts      pure geometry: (w, h) -> rects
      render/screen.ts      cell buffer, text/box primitives
      render/frame-diff.ts  Screen x Screen -> Change[] -> escape runs
      effects/*             flicker, burnin, typewriter, whisper
    panels/*                data adapters, each with its own cadence
```

## Key decisions

1. **A frame is a value, not a side effect.** `renderFrame` takes a plain object
   and returns a `Screen`. Everything the effects do is derived from `now`, which
   makes the whole visual layer testable without a terminal.
2. **Diff, never repaint.** `changes(previous, next)` produces the changed cells;
   `serialize` collapses contiguous cells in a row into one write. This is what
   keeps the dashboard from tearing on slow terminals and from flooding the PTY.
3. **Layout is arithmetic.** Panel rects come from integer division with the
   remainder pushed to the last column/row, so the grid always ends exactly at the
   screen edge. Property tests assert bounds and non-overlap across the whole
   supported range instead of eyeballing screenshots.
4. **The atmosphere is data.** Flicker windows, decay time, reveal easing and
   whisper lines live in `effects/`, and each of them exposes a pure predicate.
   Requirement R3 becomes `continuousHiddenMs(schedule, t) <= 120`.
5. **Panels are adapters.** Every panel exposes `sample(now) -> PanelData`, sync or
   async. Swapping the CI fixture for a real provider touches one file.

## Failure handling

- `git` panel: a failed `execFile` (no repository, timeout) degrades to an idle
  panel with an explanation, never an exception in the loop.
- `ci` panel: a missing or corrupt fixture falls back to the built-in fixture.
- non-TTY stdout: the CLI renders one frame and exits, so piping into a log or a
  container health check is safe.
- geometry change: the loop drops the previous frame and repaints in full.

## Performance

Allocation is bounded per frame: one `Screen` per frame plus a `Change[]`. The
loop tracks per-frame duration with `process.hrtime.bigint()` and reports
min/avg/max and the count of frames over budget with `--stats`.
