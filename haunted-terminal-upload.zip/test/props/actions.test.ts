import { describe, expect, it } from 'vitest';
import {
  mapConclusion,
  resolveActionsConfig,
  summariseRun,
  type ActionsJob,
  type ActionsRun,
} from '../../src/panels/githubActions';

const run: ActionsRun = {
  id: 991,
  name: 'ci',
  head_branch: 'feature/haunted-ui',
  head_sha: 'abcdef0123456789',
  status: 'completed',
  conclusion: 'success',
  run_number: 42,
  created_at: '2026-10-31T09:00:00Z',
  updated_at: '2026-10-31T09:02:00Z',
};

const jobs: ActionsJob[] = [
  { name: 'build', status: 'completed', conclusion: 'success', started_at: '2026-10-31T09:00:00Z', completed_at: '2026-10-31T09:00:31Z' },
  { name: 'props', status: 'completed', conclusion: 'success', started_at: '2026-10-31T09:00:31Z', completed_at: '2026-10-31T09:01:15Z' },
];

describe('github actions adapter', () => {
  it('configures itself from the environment', () => {
    const config = resolveActionsConfig(undefined, undefined, {
      GITHUB_REPOSITORY: 'someone/haunted-terminal',
      GITHUB_TOKEN: 'ghp_example',
    });
    expect(config).toEqual({ repo: 'someone/haunted-terminal', token: 'ghp_example' });
  });

  it('stays offline when the token is missing', () => {
    expect(resolveActionsConfig(undefined, undefined, { GITHUB_REPOSITORY: 'a/b' })).toBeUndefined();
    expect(resolveActionsConfig(undefined, undefined, { GITHUB_TOKEN: 'x' })).toBeUndefined();
    expect(resolveActionsConfig('a/b', 'tok', {})).toEqual({ repo: 'a/b', token: 'tok' });
  });

  it('prefers the conclusion over the raw status', () => {
    expect(mapConclusion(run)).toBe('success');
    expect(mapConclusion({ status: 'in_progress', conclusion: null })).toBe('in_progress');
    expect(mapConclusion({})).toBe('unknown');
  });

  it('summarises a run into the fixture shape', () => {
    const now = Date.parse('2026-10-31T09:03:00Z');
    const summary = summariseRun(run, jobs, now);
    expect(summary.branch).toBe('feature/haunted-ui');
    expect(summary.sha).toBe('abcdef0');
    expect(summary.status).toBe('success');
    expect(summary.durationSeconds).toBe(120);
    expect(summary.lastRunAgoSeconds).toBe(60);
    expect(summary.pullRequest).toBe(42);
    expect(summary.jobs.map((job) => job.name)).toEqual(['build', 'props']);
    expect(summary.jobs[0].seconds).toBe(31);
  });

  it('falls back to the fixture jobs when the API returns none', () => {
    const summary = summariseRun(run, [], Date.parse('2026-10-31T09:10:00Z'));
    expect(summary.jobs.length).toBeGreaterThan(0);
    expect(summary.jobs[0].name).toBe('build');
  });

  it('survives payloads with missing fields', () => {
    const now = Date.parse('2026-10-31T09:05:00Z');
    const summary = summariseRun({}, [], now);
    expect(summary.workflow.length).toBeGreaterThan(0);
    expect(summary.sha.length).toBeLessThanOrEqual(7);
    expect(Number.isFinite(summary.durationSeconds)).toBe(true);
    expect(summary.lastRunAgoSeconds).toBeGreaterThanOrEqual(0);
  });
});
