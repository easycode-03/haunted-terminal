import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import {
  MAX_HIDDEN_MS,
  MIN_GAP_MS,
  SCHEDULE_HORIZON_MS,
  continuousHiddenMs,
  makeFlickerSchedule,
} from '../../src/effects/flicker';

const schedule = makeFlickerSchedule(20261031, SCHEDULE_HORIZON_MS);

describe('ghost flicker (requirement R3)', () => {
  it('schedules something at all', () => {
    expect(schedule.length).toBeGreaterThan(10);
  });

  it('never hides the screen longer than 120ms in one stretch', () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: SCHEDULE_HORIZON_MS - 1 }), (at) => {
        const stretch = continuousHiddenMs(schedule, at);
        return stretch === 0 || stretch <= MAX_HIDDEN_MS;
      }),
      { numRuns: 2000 },
    );
  });

  it('leaves clear time between windows', () => {
    for (let index = 1; index < schedule.length; index += 1) {
      const gap = schedule[index].start - schedule[index - 1].end;
      expect(gap).toBeGreaterThanOrEqual(MIN_GAP_MS);
    }
  });

  it('keeps windows ordered and non-empty', () => {
    for (const window of schedule) {
      expect(window.end).toBeGreaterThan(window.start);
      expect(window.start).toBeGreaterThanOrEqual(0);
    }
  });

  it('is deterministic for the same seed and different across seeds', () => {
    expect(makeFlickerSchedule(7, 5000)).toEqual(makeFlickerSchedule(7, 5000));
    expect(makeFlickerSchedule(7, 5000)).not.toEqual(makeFlickerSchedule(8, 5000));
  });
});
