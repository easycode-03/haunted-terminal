import { describe, expect, it } from 'vitest';
import { makeFlickerSchedule } from '../../src/effects/flicker';
import type { PanelData } from '../../src/panels/types';
import { renderFrame } from '../../src/render/frame';
import { renderToPlainText } from '../../src/render/screen';
import { DEFAULT_THEME, THEMES, THEME_NAMES, THEME_TOKENS, resolveTheme } from '../../src/render/themes';

const panels: PanelData[] = [
  { id: 'a', title: 'System Metrics', state: 'nominal', lines: ['cpu 42%'], updatedAt: 0 },
  { id: 'b', title: 'Git Status', state: 'watch', lines: ['branch main'], updatedAt: 0 },
  { id: 'c', title: 'CI Pipeline', state: 'alarm', lines: ['ci failing'], updatedAt: 0 },
  { id: 'd', title: 'Moon Phase', state: 'nominal', lines: ['illum 78%'], updatedAt: 0 },
];

const flicker = makeFlickerSchedule(1, 60000);

describe('theme packs', () => {
  it('gives every theme all seven tokens', () => {
    for (const name of THEME_NAMES) {
      const theme = THEMES[name];
      for (const token of THEME_TOKENS) {
        expect(typeof theme[token]).toBe('string');
        expect(theme[token].length).toBeGreaterThan(0);
      }
      expect(theme.name).toBe(name);
    }
  });

  it('keeps the primary phosphor colour distinct across themes', () => {
    const phosphors = THEME_NAMES.map((name) => THEMES[name].phosphor);
    expect(new Set(phosphors).size).toBe(phosphors.length);
  });

  it('falls back to the default theme for unknown names', () => {
    expect(resolveTheme('nope')).toBe(DEFAULT_THEME);
    expect(resolveTheme(undefined)).toBe(DEFAULT_THEME);
    expect(resolveTheme('CYBERPUNK')).toBe(THEMES.cyberpunk);
  });

  it('changes the colours but never the content', () => {
    const texts = THEME_NAMES.map((name) =>
      renderToPlainText(
        renderFrame({
          width: 120,
          height: 40,
          now: 5000,
          startedAt: 0,
          panels,
          page: 0,
          plain: false,
          flicker,
          ghosts: new Map(),
          theme: THEMES[name],
        }),
      ),
    );
    expect(new Set(texts).size).toBe(1);
    expect(texts[0]).toContain('cpu 42%');
  });
});
