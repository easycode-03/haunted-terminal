import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { MIN_PANEL_H, MIN_PANEL_W, computeLayout, pagesForCapacity } from '../../src/render/layout';

const dimensions = fc.record({
  width: fc.integer({ min: 40, max: 300 }),
  height: fc.integer({ min: 12, max: 60 }),
});

describe('panel layout (requirement R2)', () => {
  it('keeps every panel rect inside the drawable area', () => {
    fc.assert(
      fc.property(dimensions, ({ width, height }) => {
        const layout = computeLayout(width, height);
        return layout.rects.every(
          (rect) =>
            rect.x >= 0 &&
            rect.y >= 1 &&
            rect.w > 0 &&
            rect.h > 0 &&
            rect.x + rect.w <= width &&
            rect.y + rect.h <= height - 1,
        );
      }),
      { numRuns: 500 },
    );
  });

  it('never overlaps two panels', () => {
    fc.assert(
      fc.property(dimensions, ({ width, height }) => {
        const rects = computeLayout(width, height).rects;
        for (let a = 0; a < rects.length; a += 1) {
          for (let b = a + 1; b < rects.length; b += 1) {
            const left = rects[a];
            const right = rects[b];
            const separated =
              left.x + left.w <= right.x ||
              right.x + right.w <= left.x ||
              left.y + left.h <= right.y ||
              right.y + right.h <= left.y;
            if (!separated) return false;
          }
        }
        return true;
      }),
      { numRuns: 500 },
    );
  });

  it('never returns more rects than panels can occupy', () => {
    fc.assert(
      fc.property(dimensions, ({ width, height }) => {
        const layout = computeLayout(width, height);
        return layout.rects.length === layout.capacity && layout.capacity >= 1 && layout.capacity <= 4;
      }),
      { numRuns: 200 },
    );
  });

  it('honours the minimum panel size it advertised', () => {
    fc.assert(
      fc.property(dimensions, ({ width, height }) => {
        const layout = computeLayout(width, height);
        // Rects that are not the rounding remainder must clear the minimums.
        return layout.rects.every((rect) => rect.w >= MIN_PANEL_W || layout.cols === 1)
          && layout.rects.every((rect) => rect.h >= MIN_PANEL_H || layout.rows === 1);
      }),
      { numRuns: 300 },
    );
  });

  it('gives a normal terminal a 2x2 grid with all four panels visible', () => {
    expect(computeLayout(120, 40).capacity).toBe(4);
    expect(computeLayout(80, 24).capacity).toBe(4);
  });

  it('degrades to a pageable single row on a 40 column terminal', () => {
    const layout = computeLayout(40, 12);
    expect(layout.capacity).toBeLessThan(4);
    expect(layout.rects.length).toBe(layout.capacity);
    expect(pagesForCapacity(4, layout.capacity)).toBeGreaterThan(1);
  });
});
