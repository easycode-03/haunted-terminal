import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { isPanel, loadPanels, loadPanelsFromList } from '../../src/plugins/loadPanels';

const dir = mkdtempSync(path.join(tmpdir(), 'haunted-plugins-'));

const valid = () => ({
  id: 'weather',
  title: 'Weather Radar',
  intervalMs: 30000,
  sample: () => ({ id: 'weather', title: 'Weather Radar', state: 'nominal', updatedAt: 0, lines: ['rain in 20m'] }),
});

writeFileSync(
  path.join(dir, 'weather.cjs'),
  `module.exports = ${JSON.stringify({ id: 'weather', title: 'Weather Radar', intervalMs: 30000 })};\nmodule.exports.sample = () => ({ id: 'weather', title: 'Weather Radar', state: 'nominal', updatedAt: 0, lines: ['rain in 20m'] });\n`,
);
writeFileSync(path.join(dir, 'broken.cjs'), 'module.exports = { id: "broken" };\n');
writeFileSync(path.join(dir, 'explodes.cjs'), 'throw new Error("nope");\n');
writeFileSync(path.join(dir, 'notes.txt'), 'ignored\n');

afterAll(() => {
  rmSync(dir, { recursive: true, force: true });
});

describe('panel plugins', () => {
  it('accepts a well formed panel and rejects half-build ones', () => {
    expect(isPanel(valid())).toBe(true);
    expect(isPanel({ id: 'x', title: 'X', intervalMs: 1 })).toBe(false);
    expect(isPanel({ id: '', title: 'X', intervalMs: 1, sample: () => 1 })).toBe(false);
    expect(isPanel({ id: 'x', title: 'X', intervalMs: 0, sample: () => 1 })).toBe(false);
    expect(isPanel(null)).toBe(false);
  });

  it('loads valid plugins, skips broken and exploding ones', () => {
    const panels = loadPanels(dir);
    expect(panels.map((panel) => panel.id)).toEqual(['weather']);
  });

  it('returns nothing for a missing directory', () => {
    expect(loadPanels(path.join(dir, 'does-not-exist'))).toEqual([]);
  });

  it('deduplicates across directories', () => {
    const merged = loadPanelsFromList([dir, dir]);
    expect(merged.length).toBe(1);
  });

  it('loads plugins from a relative directory (regression)', () => {
    const local = '.tmp-plugins-regression';
    mkdirSync(local, { recursive: true });
    writeFileSync(
      path.join(local, 'rel.cjs'),
      'module.exports = { id: "rel", title: "Rel Panel", intervalMs: 1000, sample: () => ({ id: "rel", title: "Rel Panel", state: "nominal", updatedAt: 0, lines: ["ok"] }) };\n',
    );
    try {
      expect(loadPanels(local).map((panel) => panel.id)).toEqual(['rel']);
    } finally {
      rmSync(local, { recursive: true, force: true });
    }
  });
});
