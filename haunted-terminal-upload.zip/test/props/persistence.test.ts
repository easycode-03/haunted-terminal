import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { makeFlickerSchedule } from '../../src/effects/flicker';
import type { GhostMap } from '../../src/effects/burnin';
import { renderFrame } from '../../src/render/frame';
import { renderToPlainText } from '../../src/render/screen';
import type { PanelData } from '../../src/panels/types';

const panels: PanelData[] = [
  { id: 'system', title: 'System Metrics', state: 'nominal', lines: ['cpu   ██░░ 42%'], updatedAt: 0 },
  { id: 'git', title: 'Git Status', state: 'watch', lines: ['branch    main'], updatedAt: 0 },
  { id: 'ci', title: 'CI Pipeline', state: 'alarm', lines: ['ci #42 failing'], updatedAt: 0 },
  { id: 'moon', title: 'Moon Phase', state: 'nominal', lines: ['illum 78%'], updatedAt: 0 },
];

const flicker = makeFlickerSchedule(20261031, 60000);

function rowsOf(screen: ReturnType<typeof renderFrame>): string[] {
  return screen.cells.map((row) => row.map((cell) => cell.ch).join(''));
}

describe('frame composition', () => {
  it('never lets the flicker hide a value (requirement R3)', () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 59999 }), (now) => {
        const screen = renderFrame({
          width: 120,
          height: 40,
          now,
          startedAt: 0,
          panels,
          page: 0,
          plain: false,
          flicker,
          ghosts: new Map(),
        });
        const rows = rowsOf(screen);
        return panels.every((panel) => rows.some((row) => row.includes(panel.lines[0])));
      }),
      { numRuns: 400 },
    );
  });

  it('never lets a burn-in ghost overwrite live content', () => {
    const ghosts: GhostMap = new Map();
    for (let x = 2; x < 30; x += 1) ghosts.set(`${x},1`, { ch: 'X', bornAt: 0 });
    const screen = renderFrame({
      width: 120,
      height: 40,
      now: 500,
      startedAt: -10_000,
      panels,
      page: 0,
      plain: false,
      flicker,
      ghosts,
    });
    const text = renderToPlainText(screen);
    expect(text).not.toContain('XXXX');
    expect(text).toContain('System Metrics');
  });

  it('always fills exactly the requested geometry', () => {
    fc.assert(
      fc.property(fc.integer({ min: 40, max: 200 }), fc.integer({ min: 12, max: 60 }), (width, height) => {
        const screen = renderFrame({
          width,
          height,
          now: 5000,
          startedAt: 0,
          panels,
          page: 0,
          plain: false,
          flicker,
          ghosts: new Map(),
        });
        return (
          screen.width === width &&
          screen.height === height &&
          screen.cells.length === height &&
          screen.cells.every((row) => row.length === width)
        );
      }),
      { numRuns: 200 },
    );
  });

  it('drops every ghost artefact in plain mode', () => {
    const ghosts: GhostMap = new Map([['5,2', { ch: '@', bornAt: 0 }]]);
    const screen = renderFrame({
      width: 100,
      height: 30,
      now: 1,
      startedAt: 0,
      panels,
      page: 0,
      plain: true,
      flicker,
      ghosts,
    });
    expect(renderToPlainText(screen)).not.toContain('@');
  });

  it('pages through panels the terminal cannot fit', () => {
    const small = renderFrame({
      width: 40,
      height: 12,
      now: 5000,
      startedAt: 0,
      panels,
      page: 0,
      plain: true,
      flicker,
      ghosts: new Map(),
    });
    const second = renderFrame({
      width: 40,
      height: 12,
      now: 5000,
      startedAt: 0,
      panels,
      page: 1,
      plain: true,
      flicker,
      ghosts: new Map(),
    });
    const firstText = renderToPlainText(small);
    const secondText = renderToPlainText(second);
    expect(firstText).not.toBe(secondText);
    expect(firstText).toContain('pg 1/');
  });
});
