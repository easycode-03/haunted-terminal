import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { applyChanges, changes, serialize } from '../../src/render/frame-diff';
import type { Screen } from '../../src/render/screen';

const WIDTH = 8;
const HEIGHT = 4;

const screenArbitrary: fc.Arbitrary<Screen> = fc
  .array(
    fc.array(
      fc.record({
        ch: fc.constantFrom(' ', 'x', 'y', '|', '4', '%'),
        sgr: fc.constantFrom('a', 'b', 'c'),
      }),
      { minLength: WIDTH, maxLength: WIDTH },
    ),
    { minLength: HEIGHT, maxLength: HEIGHT },
  )
  .map((rows) => ({
    width: WIDTH,
    height: HEIGHT,
    cells: rows.map((row) => row.map((cell) => ({ ch: cell.ch, sgr: cell.sgr }))),
  }));

describe('frame diff (requirement R4)', () => {
  it('reconstructs the next frame from the previous one', () => {
    fc.assert(
      fc.property(screenArbitrary, screenArbitrary, (previous, next) => {
        const rebuilt = applyChanges(previous, changes(previous, next));
        return JSON.stringify(rebuilt) === JSON.stringify(next);
      }),
      { numRuns: 300 },
    );
  });

  it('emits nothing when a frame repeats', () => {
    fc.assert(
      fc.property(screenArbitrary, (screen) => {
        const diff = changes(screen, screen);
        return diff.length === 0 && serialize(diff) === '';
      }),
      { numRuns: 200 },
    );
  });

  it('touches every differing cell exactly once', () => {
    fc.assert(
      fc.property(screenArbitrary, screenArbitrary, (previous, next) => {
        const diff = changes(previous, next);
        const keys = new Set(diff.map((change) => `${change.x},${change.y}`));
        let expected = 0;
        for (let y = 0; y < HEIGHT; y += 1) {
          for (let x = 0; x < WIDTH; x += 1) {
            const before = previous.cells[y][x];
            const after = next.cells[y][x];
            if (before.ch !== after.ch || before.sgr !== after.sgr) expected += 1;
          }
        }
        return keys.size === diff.length && diff.length === expected;
      }),
      { numRuns: 300 },
    );
  });

  it('refuses to diff two different geometries', () => {
    const small: Screen = { width: 2, height: 2, cells: [[{ ch: ' ', sgr: 'a' }, { ch: ' ', sgr: 'a' }], [{ ch: ' ', sgr: 'a' }, { ch: ' ', sgr: 'a' }]] };
    const large: Screen = { width: 3, height: 2, cells: small.cells.concat() as never };
    expect(() => changes(small, large)).toThrow();
  });
});
