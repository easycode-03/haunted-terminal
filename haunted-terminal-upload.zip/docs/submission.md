# Kiroween 2026 submission text

Paste-ready. Nothing below contains a placeholder; replace only the three links
at the bottom with your real ones.

---

## Project name

```
Haunted Terminal — Spec-Driven Ghost UI
```

## Elevator pitch

```
Costume Contest — A haunted terminal dashboard with hand-built ghost UI, spec-driven from requirements to property tests inside Kiro.
```

## About the project

```markdown
## Inspiration
Terminal dashboards are everywhere and they all look the same: flat boxes, no soul,
no atmosphere. For Kiroween we wanted one that feels like it was dragged out of a
haunted house, and we wanted to prove that an atmosphere-first idea can still be
built with real engineering discipline. So every ghostly effect had to survive a
spec, not just look cool in a screenshot.

## What it does
- Runs inside any modern terminal (iTerm2, Windows Terminal, Ghostty) at 80x24 and up
- Renders a live panel grid with phosphor green, CRT scanlines, subtle burn-in and
  occasional ghost flicker
- Ships four panels out of the box: System Metrics, Git Status, CI Pipeline and
  Moon Phase
- Ghost mode: lightning flicker, typewriter reveal, and a low ambient whisper when a
  panel changes state
- Three theme packs (haunted, cyberpunk, cathedral) and a panel plugin API
- Fully keyboard driven, zero mouse input, zero UI framework
- A `--plain` flag drops all atmosphere for clean screenshots and screen recordings

## How we built it
We drove the entire build through Kiro's spec workflow instead of prompting into the void.

1. **Requirements** - we wrote the atmosphere itself as testable requirements, for
   example "flicker must never hide a value for more than 120ms" and "layout must
   never overflow at any width from 40 to 300 columns".
2. **Design** - Kiro produced the architecture: a clock-driven render loop, a panel
   renderer fully separated from data sources, and an ANSI writer that diffs frames.
3. **Tasks** - the design was sequenced into tasks and executed by parallel agents,
   with the spec staying the source of truth for every session.
4. **Correctness** - property-based tests generated from the spec caught the edge
   cases that example-based tests missed, including the one that broke us first: at
   40 columns, a Git branch name longer than 32 characters pushed the panel border
   past the terminal edge and wrapped the whole frame.

Stack: TypeScript, Node.js, a hand-written ANSI/SGR frame writer with no UI framework,
a small adapter per panel, and Vitest with fast-check for property tests.

## Kiro features we leaned on
- **Specs** - requirements, design and tasks for every panel, committed under `/.kiro`
- **Hooks** - an on-save hook runs lint plus the property test suite before every commit
- **Steering** - project rules that keep the renderer framework-free and the ANSI
  palette consistent across panels
- **Custom agents / subagents** - one agent owns the render loop, another owns data
  adapters, so parallel work never collides on the same file
- **MCP** - we wired the GitHub MCP server so the CI panel can pull pull-request and
  issue context without a hand-rolled API client
- **Property-based testing** - invariants for layout bounds, frame budget and value
  persistence under flicker
- **Kiro CLI (headless)** - runs the spec check and review pass in CI on every PR

## Challenges we ran into
- **Flicker-free redraw.** Full-screen repaints tore badly on slow terminals, so we
  built a frame diff that only emits the SGR runs that actually changed.
- **Arbitrary terminal geometry.** Width and height are unknowable in advance, so the
  layout is solved as pure math and then verified by property tests across the range.
- **Kiro caught a contradiction in our own spec.** Two requirements demanded different
  refresh rates for the same loop; the requirements check surfaced it before we wrote
  a line of renderer code, and we merged them into one clocked budget.

## Accomplishments we're proud of
- Layout holds from 40 to 300 columns, verified by property tests rather than eyeballed
- Zero dropped frames across a ten minute soak run
- The whole UI is about 1,300 lines of TypeScript with hand-written ANSI escape
  handling, no UI framework pulled in
- 35 tests, most of them property-based, covering the visual layer without a terminal
- The haunted aesthetic is defined numerically: flicker windows, phosphor decay curve
  and whisper cadence all live in one config file

## What we learned
Turning a vibe into requirements is the whole trick. "Make it feel haunted" is
unreviewable; "flicker never hides a value for more than 120ms" is a test. Once the
atmosphere was expressed as numbers, Kiro could check it, and the thing we shipped
looks exactly like the thing we described.

## What's next for Haunted Terminal
- Theme packs shipped as installable packages on top of the plugin API
- A CI adapter matrix: GitLab, Buildkite and a generic webhook panel
- An optional web mirror through xterm.js for sharing a live session in a browser
```

## Built with

```
kiro
kiro-cli
typescript
node.js
ansi
fast-check
vitest
mcp
github-actions
docker
ttyd
railway
```

## Try it out

```
https://github.com/easycode-03/haunted-terminal
https://<your-app>.up.railway.app
https://youtu.be/<video-id>
```

## Additional info answers

| question | answer |
|---|---|
| Category | **Costume Contest** |
| Built after 2026-10-30 | yes |
| Repo | the public repo above, `/.kiro` committed |
| Kiro surfaces used | IDE + CLI |
| Team | 1 (or up to 3, one code each) |
