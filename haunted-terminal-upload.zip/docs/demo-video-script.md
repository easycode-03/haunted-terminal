# Demo video script — 2:58 target

Judges watch the first three minutes only. Everything below fits in 2:58 with
about eight seconds of slack, so a slow beat never pushes you past the cutoff.

## Recording setup

- Window: Windows Terminal (or iTerm2), font size 20+, dark background, no tabs bar.
- Geometry for the hero shot: **120 x 34** so the panel grid lands 2x2.
- Recorder: `Win + G` (Game Bar) is enough; OBS at 1920x1080/60 is better.
- **Audio on.** A silent demo reads as an unfinished demo.
- Terminal rendered at 60fps looks calmer than at 20 — use `--fps 30` on camera.

Commands to have ready in three tabs (or use a small `demo.ps1`):

```
node dist/cli.js --theme haunted                 # hero shot
node dist/cli.js --theme cyberpunk --plugins examples/plugins
node dist/cli.js --once --plain --width 120 --height 34
npm run test:props
```

## Beat sheet

| time | screen | narration (English, say it close to this) |
|---|---|---|
| 0:00–0:08 | Hero shot: 120x34 grid already running, flicker visible, typewriter masthead | "This is Haunted Terminal — a terminal dashboard that looks like it was dragged out of a haunted house. And every ghost in it is a test." |
| 0:08–0:20 | Panels light up one by one; cursor moves between panels | "Four panels: system metrics, git status, CI pipeline and the moon phase. Live data, one frame, no UI framework." |
| 0:20–0:32 | Terminal resize from 120x34 down to 60x20, then to 40x12 | "Resize it. The grid is pure arithmetic, verified from 40 to 300 columns — it reflows and pages instead of overflowing." |
| 0:32–0:45 | Press `p` for plain, back again; run the `--once --plain` command | "One flag strips all atmosphere. Same dashboard, safe to pipe into a log file." |
| 0:45–1:00 | Theme switch: haunted → cyberpunk → cathedral | "Three themes, seven colour tokens each. The renderer never hard-codes a colour index." |
| 1:00–1:35 | **Switch to Kiro.** Open `.kiro/specs/panel-grid/requirements.md`, scroll to R3 | "Here is the spec. Requirement R3 says a flicker must never hide a value for more than 120 milliseconds. That is not a vibe, that is a number we can test." |
| 1:35–1:55 | Open `test/props/flicker.test.ts`, run `npm run test:props` | "So the test asserts exactly that — continuous hidden stretch never above 120, at least 700 milliseconds of clear time between windows." |
| 1:55–2:20 | Show the failing-then-fixed case: 40 columns, long branch name; show layout test | "This one bit us first: at 40 columns a long branch name pushed the border past the edge. The layout property test now covers the whole range, so it cannot come back." |
| 2:20–2:40 | Plugin demo: `--plugins examples/plugins`, tab to page 2 showing Weather Radar | "Panels are plugins. Drop a module in a directory, pass the flag, and it is in the grid." |
| 2:40–2:52 | Slow pan across the hero shot: burn-in fading, whisper line, scanlines | "The afterimage decays in 900 milliseconds. The whisper only shows when a panel changes state. Every one of those is a pure function of time — no randomness, so every screenshot is reproducible." |
| 2:52–2:58 | Card with repo URL and `#KiroweenHackathon26` | "Repo in the description. Built with Kiro, specs and property tests first." |

## What the judges must see on camera

1. The finished thing in the first 10 seconds (Costume Contest is judged on the look).
2. The spec file — proof that `/.kiro` is real and not decoration.
3. A test run with a visible pass count.
4. One bug and its fix, told in under 25 seconds.
5. Sound. Narration over the whole clip.

## Upload

- Title: `Haunted Terminal — Spec-Driven Ghost UI (Kiroween 2026)`
- Description, first line: repo URL, then a two-line summary, then `#KiroweenHackathon26`
- Visibility: **Public** or **Unlisted** — never Private (judges cannot open it)
- Length: stop the recording at 2:58. The three-minute cutoff is enforced.

## Post-upload checklist

- [ ] Watch it once on a phone: is the terminal text readable at that size?
- [ ] No `.env`, no token, no personal path visible in any frame
- [ ] Repo link in the description opens without login
- [ ] Video starts playing without an age or region gate
- [ ] Paste the `https://youtu.be/<id>` URL into Devpost's *Demo video URL
