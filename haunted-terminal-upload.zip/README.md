# Haunted Terminal

A spec-driven terminal dashboard that looks like it was dragged out of a haunted
house: phosphor green, CRT scanlines, decaying afterimages, a typewriter masthead
and a dim whisper channel. No UI framework, no TUI library — a cell buffer, an
ANSI writer and a frame diff.

Built for **Kiroween 2026** (Costume Contest category).

```
┌ System Metrics ──────────────────────────┐ ┌ Git Status ──────────────────────────────┐
│ cpu   ████░░░░░░░░  33%                  │ │ branch    main                            │
│ mem   █████████░░░  77%                  │ │ staged    0   modified 2                  │
│ used  12.2GB / 15.7GB                    │ │ untracked 1                               │
└──────────────────────────────────────────┘ └───────────────────────────────────────────┘
```

## What it does

- Four built-in panels: System Metrics, Git Status, CI Pipeline, Moon Phase
- Live CI panel: reads real GitHub Actions runs when given a repo and a token,
  otherwise renders `fixtures/ci.json` so the demo is deterministic
- 2x2 grid on a normal terminal, pageable single row on a narrow one
- Ghost mode: seeded phosphor flicker (never hides a value for more than 120ms),
  900ms burn-in afterimages, eased typewriter titles, whisper lines on state change
- Three theme packs: `haunted`, `cyberpunk`, `cathedral`
- Panel plugins: drop a module in a directory, pass `--plugins <dir>`
- `--plain` renders the same dashboard with zero atmosphere, safe to pipe into a log
- Frame-diff redraw: only the changed cells are written, so nothing tears

## Quickstart

```bash
npm install
npm run build
node dist/cli.js                        # interactive
node dist/cli.js --once                 # one frame, plain text
node dist/cli.js --theme cyberpunk      # different mood
node dist/cli.js --plugins examples/plugins
node dist/cli.js --stats                # frame time statistics on exit
```

Keys: `q` quit, `tab` next page, `p` toggle plain.

## Flags

| flag | meaning |
|---|---|
| `--plain` | disable all atmosphere |
| `--fps <n>` | render loop rate, default 20 |
| `--once` | render one frame and exit |
| `--width <n>` / `--height <n>` | geometry for `--once` |
| `--theme <name>` | `haunted` \| `cyberpunk` \| `cathedral` |
| `--plugins <dir>` | load panel plugins (repeatable) |
| `--repo <owner/name>` | GitHub repo for the live Actions panel |
| `--token <token>` | GitHub token (prefer the `GITHUB_TOKEN` env var) |
| `--stats` | frame time min/avg/max and over-budget count |

## Live CI panel

```bash
export GITHUB_TOKEN=ghp_xxx            # token only needs actions:read
node dist/cli.js --repo owner/repo
```

The panel calls `/repos/:repo/actions/runs?per_page=1` plus the run's jobs, maps
the payload into the same shape the fixture uses, and falls back to the fixture on
any error (no network, bad token, rate limit).

## Panel plugin API

A plugin is a CommonJS module exporting a `Panel`:

```js
module.exports = {
  id: 'weather',
  title: 'Weather Radar',
  intervalMs: 30000,
  sample(now) {
    return { id: 'weather', title: 'Weather Radar', state: 'nominal',
             updatedAt: now, whisper: 'the rain is coming from the east',
             lines: ['rain   in 20m', 'wind   4 m/s NE'] };
  },
};
```

`state` is one of `nominal | watch | alarm | idle` and drives the border colour.
A broken or throwing plugin is skipped; the dashboard keeps rendering.

## Architecture

```
src/render/frame.ts       pure composition: FrameInput -> Screen
src/render/layout.ts      pure geometry: (width, height) -> panel rects
src/render/screen.ts      cell buffer, text and box primitives
src/render/frame-diff.ts  Screen x Screen -> Change[] -> escape runs
src/render/themes.ts      three palettes, seven tokens each
src/render/loop.ts        clock, panel scheduling, resize, keys, statistics
src/effects/              flicker, burn-in, typewriter, whisper
src/panels/               system, git, ci fixture, github actions, moon
src/plugins/loadPanels.ts panel plugin loader
```

`renderFrame` is a pure function of `(now, config)`. That is the whole trick: the
visual layer is testable without a terminal, and every effect is a predicate the
property tests can hammer.

## Spec-driven development

The spec lives in `.kiro/specs/panel-grid/`:

- `requirements.md` — R1..R7, including "a single hidden stretch never exceeds 120ms"
- `design.md` — layers, decisions, failure handling, performance
- `tasks.md` — the task list the implementation followed

`.kiro/steering/ansi-style.md` holds the palette and layout rules, and
`.kiro/hooks/on-save.json` runs `npm run lint && npm run test:props` on save.

## Tests

```bash
npm run test:props
```

35 tests (fast-check property tests where the invariant is worth proving):

- layout bounds and non-overlap for 40..300 columns × 12..60 rows
- frame diff round-trip: applying the emitted changes reproduces the next frame
- flicker: continuous hidden stretch ≤ 120ms, ≥ 700ms clear time between windows
- value persistence: a panel value survives every flicker phase
- ghosts never overwrite live content
- themes change colour, never content
- plugin loader accepts good modules, skips broken and throwing ones
- GitHub Actions payload mapping, including missing-field payloads

## Deploy

Container (already wired for Railway / Fly.io):

```bash
docker build -t haunted-terminal .
docker run -p 8080:8080 haunted-terminal
```

The image serves the dashboard through `ttyd`, so a browser gets a real terminal
at `http://localhost:8080`.

## License

MIT
