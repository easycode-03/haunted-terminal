#!/usr/bin/env node
import { DEFAULT_SEED, SCHEDULE_HORIZON_MS, makeFlickerSchedule } from './effects/flicker';
import type { GhostMap } from './effects/burnin';
import { ciPanel } from './panels/ci';
import { createGitPanel } from './panels/git';
import { createActionsPanel, resolveActionsConfig } from './panels/githubActions';
import { moonPanel } from './panels/moon';
import { systemPanel } from './panels/system';
import type { Panel, PanelData } from './panels/types';
import { loadPanelsFromList } from './plugins/loadPanels';
import { renderFrame } from './render/frame';
import { startLoop } from './render/loop';
import { renderToPlainText } from './render/screen';
import { DEFAULT_THEME_NAME, THEME_NAMES, resolveTheme, type Theme } from './render/themes';
import { stripAnsi } from './util/format';

const VERSION = '1.0.0';

type Options = {
  plain: boolean;
  fps: number;
  stats: boolean;
  once: boolean;
  width: number;
  height: number;
  help: boolean;
  version: boolean;
  theme: string;
  pluginDirs: string[];
  repo: string | undefined;
  token: string | undefined;
};

const HELP = `haunted-terminal ${VERSION}

Usage:
  haunted-terminal [options]

Options:
  --plain              disable all atmosphere (clean screenshots, CI logs)
  --fps <n>            render loop rate, default 20
  --once               render a single frame and exit
  --width <n>          frame width for --once, default 100
  --height <n>         frame height for --once, default 30
  --theme <name>       ${THEME_NAMES.join(' | ')} (default ${DEFAULT_THEME_NAME})
  --plugins <dir>      load panel plugins from a directory (repeatable)
  --repo <owner/name>  GitHub repo for the live Actions panel
  --token <token>      GitHub token, or set GITHUB_TOKEN
  --stats              print frame time statistics on exit
  --version            print version
  --help               print this help

Live CI panel: give --repo plus GITHUB_TOKEN (env is safer than the flag) and the
CI panel reads real workflow runs; otherwise it renders fixtures/ci.json.

Keys (interactive): q quit, tab page, p toggle plain`;

function readNumber(raw: string | undefined, fallback: number): number {
  if (raw === undefined) return fallback;
  const value = Number(raw);
  return Number.isFinite(value) ? value : fallback;
}

export function parseArgs(argv: string[]): Options {
  const options: Options = {
    plain: false,
    fps: 20,
    stats: false,
    once: false,
    width: 100,
    height: 30,
    help: false,
    version: false,
    theme: DEFAULT_THEME_NAME,
    pluginDirs: [],
    repo: undefined,
    token: undefined,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const equals = arg.indexOf('=');
    const flag = equals >= 0 ? arg.slice(0, equals) : arg;
    const inlineValue = equals >= 0 ? arg.slice(equals + 1) : undefined;
    const takeValue = (): string | undefined => inlineValue ?? argv[++index];

    switch (flag) {
      case '--plain':
        options.plain = true;
        break;
      case '--fps':
        options.fps = Math.max(1, Math.min(60, readNumber(takeValue(), options.fps)));
        break;
      case '--once':
        options.once = true;
        break;
      case '--width':
        options.width = Math.max(20, readNumber(takeValue(), options.width));
        break;
      case '--height':
        options.height = Math.max(8, readNumber(takeValue(), options.height));
        break;
      case '--theme': {
        const value = takeValue();
        if (value) options.theme = value;
        break;
      }
      case '--plugins': {
        const value = takeValue();
        if (value) options.pluginDirs.push(value);
        break;
      }
      case '--repo':
        options.repo = takeValue() ?? options.repo;
        break;
      case '--token':
        options.token = takeValue() ?? options.token;
        break;
      case '--stats':
        options.stats = true;
        break;
      case '--version':
      case '-v':
        options.version = true;
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
      default:
        break;
    }
  }

  return options;
}

export function buildPanels(
  options: Pick<Options, 'repo' | 'token' | 'pluginDirs'>,
  repoDir: string = process.cwd(),
): Panel[] {
  const actionsConfig = resolveActionsConfig(options.repo, options.token);
  const ci = actionsConfig ? createActionsPanel(actionsConfig) : ciPanel;
  const base: Panel[] = [systemPanel, createGitPanel(repoDir), ci, moonPanel];
  const plugins = loadPanelsFromList(options.pluginDirs);
  const used = new Set(base.map((panel) => panel.id));
  return base.concat(plugins.filter((panel) => !used.has(panel.id)));
}

async function collect(panels: Panel[]): Promise<PanelData[]> {
  const now = Date.now();
  const out: PanelData[] = [];
  for (const panel of panels) out.push(await panel.sample(now));
  return out;
}

async function main(): Promise<void> {
  const options = parseArgs(process.argv.slice(2));

  if (options.help) {
    process.stdout.write(HELP + '\n');
    return;
  }
  if (options.version) {
    process.stdout.write(`${VERSION}\n`);
    return;
  }

  const theme: Theme = resolveTheme(options.theme);
  const panels = buildPanels(options);
  const interactive = process.stdout.isTTY === true && options.once === false;

  if (!interactive) {
    const panelsData = await collect(panels);
    const ghosts: GhostMap = new Map();
    const screen = renderFrame({
      width: options.width,
      height: options.height,
      now: Date.now(),
      startedAt: Date.now() - 10_000,
      panels: panelsData,
      page: 0,
      plain: options.plain,
      flicker: makeFlickerSchedule(DEFAULT_SEED, SCHEDULE_HORIZON_MS),
      ghosts,
      theme,
    });
    process.stdout.write(stripAnsi(renderToPlainText(screen)) + '\n');
    return;
  }

  const stats = await startLoop({ fps: options.fps, plain: options.plain, stats: options.stats, panels, theme });
  if (options.stats) {
    process.stderr.write(
      `frames ${stats.frames}  min ${stats.minMs.toFixed(2)}ms  avg ${stats.avgMs.toFixed(2)}ms  max ${stats.maxMs.toFixed(2)}ms  over-budget ${stats.dropped}\n`,
    );
  }
}

main().catch((error: unknown) => {
  process.stderr.write(`haunted-terminal failed: ${String(error)}\n`);
  process.exitCode = 1;
});
