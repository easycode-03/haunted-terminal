import type { Screen } from '../render/screen';

/**
 * Phosphor burn-in: when a bright character disappears, its afterimage lingers
 * for GHOST_DECAY_MS and fades. Ghosts never overwrite live content - they are
 * painted first and boxes are drawn on top.
 */

export type Ghost = { ch: string; bornAt: number };
export type GhostMap = Map<string, Ghost>;

export const GHOST_DECAY_MS = 900;

export function cellKey(x: number, y: number): string {
  return `${x},${y}`;
}

export function parseCellKey(key: string): { x: number; y: number } | undefined {
  const parts = key.split(',');
  if (parts.length !== 2) return undefined;
  const x = Number(parts[0]);
  const y = Number(parts[1]);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return undefined;
  return { x, y };
}

export function ghostIntensity(ghost: Ghost, now: number, decayMs: number = GHOST_DECAY_MS): number {
  const age = now - ghost.bornAt;
  if (age < 0 || age >= decayMs) return 0;
  return 1 - age / decayMs;
}

/** Records the characters that vanished between two frames. */
export function harvestGhosts(previous: Screen, next: Screen, ghosts: GhostMap, now: number): void {
  if (previous.width !== next.width || previous.height !== next.height) return;
  for (let y = 0; y < next.height; y += 1) {
    for (let x = 0; x < next.width; x += 1) {
      const before = previous.cells[y][x];
      const after = next.cells[y][x];
      if (before.ch !== after.ch && before.ch !== ' ' && after.ch === ' ') {
        ghosts.set(cellKey(x, y), { ch: before.ch, bornAt: now });
      }
    }
  }
}

export function pruneGhosts(ghosts: GhostMap, now: number): void {
  for (const [key, ghost] of ghosts) {
    if (ghostIntensity(ghost, now) <= 0) ghosts.delete(key);
  }
}
