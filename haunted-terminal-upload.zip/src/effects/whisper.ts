import type { PanelState } from '../panels/types';

/**
 * The whisper channel: a dim line under each panel that only appears when a
 * panel changes state. It is deterministic (tick-indexed) so screenshots and
 * tests are stable.
 */

export const WHISPERS: Record<PanelState, readonly string[]> = {
  nominal: ['the walls are quiet', 'all bones accounted for', 'nothing stirs', 'the candle holds'],
  watch: ['something changed upstairs', 'a door left open', 'the board flickers once', 'footsteps, maybe'],
  alarm: ['run', 'it knows your name', 'the fuse is burning', 'get out'],
  idle: ['waiting', 'the line is dead', 'no signal from below'],
};

export function whisperFor(state: PanelState, tick: number): string {
  const list = WHISPERS[state] ?? WHISPERS.nominal;
  const index = Math.abs(Math.trunc(tick)) % list.length;
  return list[index];
}

export function whisperOpacity(ageMs: number, windowMs = 2500): number {
  if (ageMs < 0 || ageMs >= windowMs) return 0;
  return 1 - ageMs / windowMs;
}
