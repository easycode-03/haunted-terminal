/**
 * Typewriter reveal for panel titles and the masthead. Eased so it reads like a
 * tube warming up rather than a linear stutter.
 */

export const DEFAULT_REVEAL_MS = 800;

export function revealCount(elapsedMs: number, total: number, durationMs: number = DEFAULT_REVEAL_MS): number {
  const length = Math.max(0, Math.trunc(total));
  if (length === 0) return 0;
  if (durationMs <= 0) return length;
  if (elapsedMs <= 0) return 0;
  if (elapsedMs >= durationMs) return length;
  const t = elapsedMs / durationMs;
  const eased = 1 - (1 - t) ** 3;
  return Math.min(length, Math.max(0, Math.round(eased * length)));
}

export function revealText(text: string, elapsedMs: number, durationMs: number = DEFAULT_REVEAL_MS): string {
  const chars = Array.from(text);
  const visible = revealCount(elapsedMs, chars.length, durationMs);
  return chars.slice(0, visible).join('');
}
