/**
 * Ghost flicker. Requirement R3: flicker must never hide a value for more than
 * 120ms, and two windows must never touch (min 700ms of clear time between).
 *
 * The schedule is seeded, so the demo looks alive but every run is reproducible
 * and testable.
 */

export type FlickerWindow = { start: number; end: number };

export const MAX_HIDDEN_MS = 120;
export const MIN_GAP_MS = 700;
export const SCHEDULE_HORIZON_MS = 60_000;
export const DEFAULT_SEED = 20261031;

/** Deterministic PRNG: same seed, same flicker, forever. */
export function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4_294_967_296;
  };
}

export function makeFlickerSchedule(seed: number, horizonMs: number = SCHEDULE_HORIZON_MS): FlickerWindow[] {
  const random = mulberry32(seed);
  const windows: FlickerWindow[] = [];
  let cursor = MIN_GAP_MS;

  while (cursor < horizonMs) {
    const length = 30 + Math.floor(random() * (MAX_HIDDEN_MS - 30)); // 30..119ms
    windows.push({ start: cursor, end: cursor + length });
    cursor += length + MIN_GAP_MS + Math.floor(random() * 1800);
  }

  return windows;
}

export function isHidden(windows: FlickerWindow[], at: number): boolean {
  for (const window of windows) {
    if (at >= window.start && at < window.end) return true;
  }
  return false;
}

/** Length of the uninterrupted hidden stretch that contains `at`. */
export function continuousHiddenMs(windows: FlickerWindow[], at: number): number {
  for (const window of windows) {
    if (at >= window.start && at < window.end) return window.end - window.start;
  }
  return 0;
}

export function totalHiddenMs(windows: FlickerWindow[], from: number, to: number): number {
  let total = 0;
  for (const window of windows) {
    const start = Math.max(window.start, from);
    const end = Math.min(window.end, to);
    if (end > start) total += end - start;
  }
  return total;
}
