import os from 'node:os';
import { bar, bytes, duration } from '../util/format';
import type { Panel, PanelData } from './types';

type CpuSample = { idle: number; total: number };

function readCpuSample(): CpuSample {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    const times = cpu.times;
    total += times.user + times.nice + times.sys + times.idle + times.irq;
    idle += times.idle;
  }
  return { idle, total };
}

let previousSample = readCpuSample();

export const systemPanel: Panel = {
  id: 'system',
  title: 'System Metrics',
  intervalMs: 1000,
  sample(): PanelData {
    const now = Date.now();
    const current = readCpuSample();
    const idleDelta = current.idle - previousSample.idle;
    const totalDelta = current.total - previousSample.total;
    previousSample = current;

    const busy = totalDelta > 0 ? Math.min(100, Math.max(0, 100 - (idleDelta / totalDelta) * 100)) : 0;
    const totalMem = os.totalmem();
    const usedMem = totalMem - os.freemem();
    const memPercent = totalMem > 0 ? (usedMem / totalMem) * 100 : 0;

    const state = busy > 85 || memPercent > 92 ? 'alarm' : busy > 55 || memPercent > 80 ? 'watch' : 'nominal';

    return {
      id: 'system',
      title: 'System Metrics',
      state,
      updatedAt: now,
      whisper: state === 'alarm' ? 'something is breathing in the fans' : undefined,
      lines: [
        `cpu   ${bar(busy, 100, 12)} ${busy.toFixed(0).padStart(3)}%`,
        `mem   ${bar(usedMem, totalMem, 12)} ${memPercent.toFixed(0).padStart(3)}%`,
        `used  ${bytes(usedMem)} / ${bytes(totalMem)}`,
        `up    ${duration(os.uptime())}  ${os.cpus().length} cores`,
      ],
    };
  },
};
