import { duration } from '../util/format';
import { loadFixture, type CiFixture } from './fixture';
import type { Panel, PanelData } from './types';

export function fixtureToPanelData(fixture: CiFixture, now: number): PanelData {
  const failed = fixture.status !== 'passing';
  return {
    id: 'ci',
    title: 'CI Pipeline',
    state: failed ? 'alarm' : 'nominal',
    updatedAt: now,
    whisper: failed ? 'the pipeline screams at 3am' : undefined,
    lines: [
      `${fixture.workflow} #${fixture.pullRequest} ${fixture.status}`,
      `branch ${fixture.branch} @ ${fixture.sha}`,
      `took   ${duration(fixture.durationSeconds)}  ago ${duration(fixture.lastRunAgoSeconds)}`,
      ...fixture.jobs
        .slice(0, 2)
        .map((job) => `${job.name.padEnd(6)} ${job.status} ${job.seconds}s`),
    ],
  };
}

/** Offline panel: reads `fixtures/ci.json`, never touches the network. */
export const ciPanel: Panel = {
  id: 'ci',
  title: 'CI Pipeline',
  intervalMs: 10000,
  async sample(): Promise<PanelData> {
    const fixture = await loadFixture();
    return fixtureToPanelData(fixture, Date.now());
  },
};
