export type PanelState = 'nominal' | 'watch' | 'alarm' | 'idle';

export type PanelData = {
  id: string;
  title: string;
  state: PanelState;
  lines: string[];
  whisper?: string;
  updatedAt: number;
};

export type Panel = {
  id: string;
  title: string;
  /** How often the loop asks this panel for data, in milliseconds. */
  intervalMs: number;
  sample: (now: number) => PanelData | Promise<PanelData>;
};
