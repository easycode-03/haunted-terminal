import { fixtureToPanelData } from './ci';
import { FALLBACK_FIXTURE, loadFixture, type CiFixture, type CiJob } from './fixture';
import type { Panel, PanelData } from './types';

export type ActionsRun = {
  id?: number;
  name?: string;
  head_branch?: string;
  head_sha?: string;
  status?: string;
  conclusion?: string | null;
  run_number?: number;
  created_at?: string;
  updated_at?: string;
  html_url?: string;
};

export type ActionsJob = {
  name?: string;
  status?: string;
  conclusion?: string | null;
  started_at?: string;
  completed_at?: string | null;
};

export type ActionsConfig = { repo: string; token: string; baseUrl?: string };

/**
 * Live GitHub Actions adapter. Configuration comes from `--repo` / `--token` or
 * from GITHUB_REPOSITORY / GITHUB_TOKEN. When either is missing the CLI keeps
 * the offline fixture panel instead.
 */
export function resolveActionsConfig(
  repo?: string,
  token?: string,
  env: NodeJS.ProcessEnv = process.env,
): ActionsConfig | undefined {
  const resolvedRepo = repo ?? env.GITHUB_REPOSITORY;
  const resolvedToken = token ?? env.GITHUB_TOKEN ?? env.GH_TOKEN;
  if (!resolvedRepo || !resolvedToken) return undefined;
  return { repo: resolvedRepo, token: resolvedToken };
}

function secondsBetween(start?: string | null, end?: string | null): number {
  if (!start || !end) return 0;
  const from = Date.parse(start);
  const to = Date.parse(end);
  if (!Number.isFinite(from) || !Number.isFinite(to) || to < from) return 0;
  return Math.round((to - from) / 1000);
}

export function mapConclusion(run: ActionsRun): string {
  if (run.conclusion) return run.conclusion;
  return run.status ?? 'unknown';
}

/** Pure: turns two API payloads into the same shape the fixture panel renders. */
export function summariseRun(
  run: ActionsRun,
  jobs: ActionsJob[],
  now: number,
  fallback: CiFixture = FALLBACK_FIXTURE,
): CiFixture {
  const mapped: CiJob[] = jobs.map((job, index) => ({
    name: job.name ?? `job${index + 1}`,
    status: job.conclusion ?? job.status ?? 'unknown',
    seconds: secondsBetween(job.started_at, job.completed_at),
  }));

  const updated = run.updated_at ? Date.parse(run.updated_at) : Number.NaN;
  return {
    workflow: run.name ?? fallback.workflow,
    status: mapConclusion(run),
    branch: run.head_branch ?? fallback.branch,
    sha: (run.head_sha ?? fallback.sha).slice(0, 7),
    pullRequest: run.run_number ?? fallback.pullRequest,
    durationSeconds: secondsBetween(run.created_at, run.updated_at),
    lastRunAgoSeconds: Number.isFinite(updated)
      ? Math.max(0, Math.round((now - updated) / 1000))
      : fallback.lastRunAgoSeconds,
    jobs: mapped.length > 0 ? mapped : fallback.jobs,
  };
}

async function fetchJson(url: string, headers: Record<string, string>, timeoutMs = 4000): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { headers, signal: controller.signal });
    if (!response.ok) throw new Error(`GitHub responded ${response.status}`);
    return (await response.json()) as unknown;
  } finally {
    clearTimeout(timer);
  }
}

export function createActionsPanel(config: ActionsConfig): Panel {
  const baseUrl = (config.baseUrl ?? 'https://api.github.com').replace(/\/+$/, '');
  return {
    id: 'ci',
    title: 'CI Pipeline',
    intervalMs: 30000,
    async sample(): Promise<PanelData> {
      const now = Date.now();
      const headers: Record<string, string> = {
        accept: 'application/vnd.github+json',
        authorization: `Bearer ${config.token}`,
        'x-github-api-version': '2022-11-28',
        'user-agent': 'haunted-terminal',
      };

      try {
        const runs = (await fetchJson(`${baseUrl}/repos/${config.repo}/actions/runs?per_page=1`, headers)) as {
          workflow_runs?: ActionsRun[];
        };
        const run = runs.workflow_runs?.[0];
        if (!run) throw new Error('no workflow runs');

        let jobs: ActionsJob[] = [];
        if (typeof run.id === 'number') {
          const jobPayload = (await fetchJson(`${baseUrl}/repos/${config.repo}/actions/runs/${run.id}/jobs?per_page=10`, headers)) as {
            jobs?: ActionsJob[];
          };
          jobs = jobPayload.jobs ?? [];
        }

        return fixtureToPanelData(summariseRun(run, jobs, now), now);
      } catch {
        return fixtureToPanelData(await loadFixture(), now);
      }
    },
  };
}
