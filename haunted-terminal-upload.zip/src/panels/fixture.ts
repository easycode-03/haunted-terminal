import { readFile } from 'node:fs/promises';
import path from 'node:path';

export type CiJob = { name: string; status: string; seconds: number };

export type CiFixture = {
  workflow: string;
  status: string;
  branch: string;
  sha: string;
  pullRequest: number;
  durationSeconds: number;
  lastRunAgoSeconds: number;
  jobs: CiJob[];
};

export const FALLBACK_FIXTURE: CiFixture = {
  workflow: 'ci',
  status: 'passing',
  branch: 'main',
  sha: '9f2c1ab',
  pullRequest: 42,
  durationSeconds: 96,
  lastRunAgoSeconds: 240,
  jobs: [
    { name: 'build', status: 'passing', seconds: 31 },
    { name: 'props', status: 'passing', seconds: 44 },
    { name: 'audit', status: 'passing', seconds: 21 },
  ],
};

/**
 * The offline fixture keeps the dashboard deterministic on stage and inside the
 * container. A live adapter (GitHub Actions) falls back to this on any error.
 */
export async function loadFixture(baseDir: string = process.cwd()): Promise<CiFixture> {
  try {
    const file = path.join(baseDir, 'fixtures', 'ci.json');
    const raw = await readFile(file, 'utf8');
    const parsed = JSON.parse(raw) as Partial<CiFixture>;
    return { ...FALLBACK_FIXTURE, ...parsed };
  } catch {
    return FALLBACK_FIXTURE;
  }
}
