import { bar } from '../util/format';
import type { Panel, PanelData } from './types';

const SYNODIC_MONTH = 29.530588853;
const KNOWN_NEW_MOON = Date.UTC(2000, 0, 6, 18, 14);

export const PHASE_NAMES = [
  'New Moon',
  'Waxing Crescent',
  'First Quarter',
  'Waxing Gibbous',
  'Full Moon',
  'Waning Gibbous',
  'Last Quarter',
  'Waning Crescent',
] as const;

export type MoonPhase = {
  age: number;
  illumination: number;
  index: number;
  name: string;
  daysToFull: number;
};

export function moonPhase(at: Date): MoonPhase {
  const days = (at.getTime() - KNOWN_NEW_MOON) / 86_400_000;
  const age = ((days % SYNODIC_MONTH) + SYNODIC_MONTH) % SYNODIC_MONTH;
  const illumination = (1 - Math.cos((2 * Math.PI * age) / SYNODIC_MONTH)) / 2;
  const index = Math.round((age / SYNODIC_MONTH) * 8) % 8;
  const half = SYNODIC_MONTH / 2;
  const daysToFull = age <= half ? half - age : SYNODIC_MONTH - age + half;
  return { age, illumination, index, name: PHASE_NAMES[index], daysToFull };
}

export const moonPanel: Panel = {
  id: 'moon',
  title: 'Moon Phase',
  intervalMs: 60000,
  sample(): PanelData {
    const now = Date.now();
    const phase = moonPhase(new Date(now));
    return {
      id: 'moon',
      title: 'Moon Phase',
      state: 'nominal',
      updatedAt: now,
      whisper: phase.illumination > 0.95 ? 'the moon is watching, stay inside' : undefined,
      lines: [
        `phase ${phase.name}`,
        `illum ${bar(phase.illumination, 1, 12)} ${Math.round(phase.illumination * 100)}%`,
        `age   ${phase.age.toFixed(1)} / ${SYNODIC_MONTH.toFixed(1)} days`,
        `full  in ${phase.daysToFull.toFixed(1)} days`,
      ],
    };
  },
};
