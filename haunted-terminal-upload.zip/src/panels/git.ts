import { execFile } from 'node:child_process';
import type { Panel, PanelData } from './types';

function git(args: string[], cwd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(
      'git',
      args,
      { cwd, timeout: 2000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
      (error, stdout) => {
        if (error) reject(error);
        else resolve(String(stdout));
      },
    );
  });
}

export function createGitPanel(repoDir: string = process.cwd()): Panel {
  return {
    id: 'git',
    title: 'Git Status',
    intervalMs: 5000,
    async sample(): Promise<PanelData> {
      const now = Date.now();
      try {
        const branch = (await git(['rev-parse', '--abbrev-ref', 'HEAD'], repoDir)).trim() || 'detached';
        const head = (await git(['rev-parse', '--short', 'HEAD'], repoDir)).trim();
        const porcelain = (await git(['status', '--porcelain'], repoDir))
          .split('\n')
          .filter((line) => line.trim().length > 0);

        const untracked = porcelain.filter((line) => line.startsWith('??')).length;
        const tracked = porcelain.filter((line) => !line.startsWith('??'));
        const staged = tracked.filter((line) => line[0] !== ' ').length;
        const modified = tracked.filter((line) => line[1] !== ' ').length;
        const dirty = untracked + staged + modified;

        return {
          id: 'git',
          title: 'Git Status',
          state: dirty > 0 ? 'watch' : 'nominal',
          updatedAt: now,
          whisper: untracked > 0 ? 'untracked souls still wander the tree' : undefined,
          lines: [
            `branch    ${branch}`,
            `head      ${head || 'no commits'}`,
            `staged    ${staged}   modified ${modified}`,
            `untracked ${untracked}`,
          ],
        };
      } catch {
        return {
          id: 'git',
          title: 'Git Status',
          state: 'idle',
          updatedAt: now,
          lines: ['no repository', 'run inside a git work tree'],
        };
      }
    },
  };
}
