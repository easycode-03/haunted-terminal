/**
 * Small formatting helpers. No dependencies, no cleverness: everything here is
 * pure so the property tests can hammer it.
 */

export function truncate(text: string, maxWidth: number): string {
  if (maxWidth <= 0) return '';
  const chars = Array.from(text);
  if (chars.length <= maxWidth) return chars.join('');
  if (maxWidth === 1) return '…';
  return chars.slice(0, maxWidth - 1).join('') + '…';
}

export function bar(value: number, max: number, width: number): string {
  const safeWidth = Math.max(1, Math.trunc(width));
  const ratio = max <= 0 ? 0 : Math.max(0, Math.min(1, value / max));
  const filled = Math.round(ratio * safeWidth);
  return '█'.repeat(filled) + '░'.repeat(safeWidth - filled);
}

export function bytes(value: number): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let remaining = Math.max(0, value);
  let index = 0;
  while (remaining >= 1024 && index < units.length - 1) {
    remaining /= 1024;
    index += 1;
  }
  return `${remaining.toFixed(index === 0 ? 0 : 1)}${units[index]}`;
}

export function duration(totalSeconds: number): string {
  const seconds = Math.max(0, Math.floor(totalSeconds));
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

const ANSI_PATTERN = /\u001b\[[0-9;?]*[A-Za-z]/g;

export function stripAnsi(text: string): string {
  return text.replace(ANSI_PATTERN, '');
}
