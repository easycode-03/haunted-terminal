import { readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import type { Panel } from '../panels/types';

/**
 * Panel plugin API. A plugin is a compiled CommonJS module in a directory that
 * exports (or default-exports) an object satisfying the `Panel` contract:
 *
 *   module.exports = {
 *     id: 'weather',
 *     title: 'Weather Radar',
 *     intervalMs: 30000,
 *     sample: (now) => ({ id: 'weather', title: 'Weather Radar', state: 'nominal',
 *                         updatedAt: now, lines: ['rain in 20m'] }),
 *   };
 *
 * A broken plugin is skipped, never fatal: the dashboard keeps rendering.
 */
export function isPanel(value: unknown): value is Panel {
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate.id === 'string' &&
    candidate.id.length > 0 &&
    typeof candidate.title === 'string' &&
    candidate.title.length > 0 &&
    typeof candidate.intervalMs === 'number' &&
    Number.isFinite(candidate.intervalMs) &&
    candidate.intervalMs > 0 &&
    typeof candidate.sample === 'function'
  );
}

export function loadPanels(dir: string): Panel[] {
  const panels: Panel[] = [];
  let entries: string[];
  try {
    entries = readdirSync(dir);
  } catch {
    return panels;
  }

  for (const entry of entries.sort()) {
    if (!entry.endsWith('.js') && !entry.endsWith('.cjs')) continue;
    // Absolute on purpose: a relative path would be resolved as a package name
    // by require(), which silently yields zero plugins.
    const file = path.resolve(dir, entry);
    try {
      if (!statSync(file).isFile()) continue;
      const loaded = require(file) as unknown;
      const candidate =
        typeof loaded === 'object' && loaded !== null && 'default' in (loaded as Record<string, unknown>)
          ? (loaded as { default: unknown }).default
          : loaded;
      if (isPanel(candidate)) panels.push(candidate);
    } catch {
      // deliberately swallowed: one bad plugin must not blank the dashboard
    }
  }

  return panels;
}

export function loadPanelsFromList(directories: string[]): Panel[] {
  const panels: Panel[] = [];
  const seen = new Set<string>();
  for (const directory of directories) {
    for (const panel of loadPanels(directory)) {
      if (seen.has(panel.id)) continue;
      seen.add(panel.id);
      panels.push(panel);
    }
  }
  return panels;
}
