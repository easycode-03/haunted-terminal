import { fg } from './ansi';

/**
 * Theme packs. A theme is seven SGR strings and nothing else - the renderer
 * never hard-codes a colour index, which is what makes swapping the whole mood
 * a one-line flag (`--theme cyberpunk`).
 */
export type Theme = {
  name: string;
  phosphor: string;
  phosphorDim: string;
  ghost: string;
  bone: string;
  blood: string;
  ash: string;
  candle: string;
};

export const THEMES: Record<string, Theme> = {
  haunted: {
    name: 'haunted',
    phosphor: fg(82),
    phosphorDim: fg(22),
    ghost: fg(28),
    bone: fg(250),
    blood: fg(160),
    ash: fg(240),
    candle: fg(220),
  },
  cyberpunk: {
    name: 'cyberpunk',
    phosphor: fg(51),
    phosphorDim: fg(23),
    ghost: fg(31),
    bone: fg(231),
    blood: fg(197),
    ash: fg(244),
    candle: fg(226),
  },
  cathedral: {
    name: 'cathedral',
    phosphor: fg(188),
    phosphorDim: fg(95),
    ghost: fg(60),
    bone: fg(255),
    blood: fg(131),
    ash: fg(246),
    candle: fg(179),
  },
};

export const DEFAULT_THEME_NAME = 'haunted';
export const DEFAULT_THEME = THEMES[DEFAULT_THEME_NAME];
export const THEME_NAMES = Object.keys(THEMES);

export function resolveTheme(name: string | undefined): Theme {
  if (!name) return DEFAULT_THEME;
  return THEMES[name.toLowerCase()] ?? DEFAULT_THEME;
}

export const THEME_TOKENS = ['phosphor', 'phosphorDim', 'ghost', 'bone', 'blood', 'ash', 'candle'] as const;
