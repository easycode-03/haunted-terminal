import { CONTROL } from './ansi';
import { changes, serialize } from './frame-diff';
import { createScreen, type Screen } from './screen';
import { computeLayout, pagesForCapacity } from './layout';
import { renderFrame } from './frame';
import type { Theme } from './themes';
import { harvestGhosts, pruneGhosts, type GhostMap } from '../effects/burnin';
import { DEFAULT_SEED, SCHEDULE_HORIZON_MS, makeFlickerSchedule } from '../effects/flicker';
import type { Panel, PanelData } from '../panels/types';

export type LoopOptions = {
  fps: number;
  plain: boolean;
  stats: boolean;
  panels: Panel[];
  theme?: Theme;
};

export type LoopStats = { frames: number; minMs: number; avgMs: number; maxMs: number; dropped: number };

export function summarise(samples: number[], dropped: number): LoopStats {
  const total = samples.reduce((sum, value) => sum + value, 0);
  return {
    frames: samples.length,
    minMs: samples.length > 0 ? Math.min(...samples) : 0,
    avgMs: samples.length > 0 ? total / samples.length : 0,
    maxMs: samples.length > 0 ? Math.max(...samples) : 0,
    dropped,
  };
}

export async function startLoop(options: LoopOptions): Promise<LoopStats> {
  const out = process.stdout;
  const panels = options.panels;
  const startedAt = Date.now();
  const ghosts: GhostMap = new Map();
  const flicker = makeFlickerSchedule(DEFAULT_SEED, SCHEDULE_HORIZON_MS);
  const data: PanelData[] = [];

  for (const panel of panels) data.push(await panel.sample(Date.now()));

  let plain = options.plain;
  let page = 0;
  let previous: Screen | null = null;
  let timer: NodeJS.Timeout | undefined;
  const samples: number[] = [];
  const lastRefresh = new Map<string, number>();
  let dropped = 0;
  const budget = 1000 / Math.max(1, options.fps);

  out.write(CONTROL.altScreen + CONTROL.hideCursor + CONTROL.clear + CONTROL.home);

  const finish = (): LoopStats => {
    if (timer) clearInterval(timer);
    out.write(CONTROL.showCursor + CONTROL.mainScreen + CONTROL.reset);
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    return summarise(samples, dropped);
  };

  const tick = (): void => {
    const frameStart = process.hrtime.bigint();
    const now = Date.now();
    const width = out.columns ?? 100;
    const height = out.rows ?? 30;

    for (let index = 0; index < panels.length; index += 1) {
      const panel = panels[index];
      const last = lastRefresh.get(panel.id) ?? 0;
      if (now - last < panel.intervalMs) continue;
      lastRefresh.set(panel.id, now);
      void Promise.resolve(panel.sample(now))
        .then((next) => {
          data[index] = next;
        })
        .catch(() => undefined);
    }

    const screen = renderFrame({ width, height, now, startedAt, panels: data, page, plain, flicker, ghosts, theme: options.theme });

    if (previous) {
      harvestGhosts(previous, screen, ghosts, now);
      pruneGhosts(ghosts, now);
      out.write(serialize(changes(previous, screen)));
    } else {
      out.write(CONTROL.clear + CONTROL.home + serialize(changes(createScreen(width, height), screen)));
    }
    previous = screen;

    const frameEnd = process.hrtime.bigint();
    const elapsedMs = Number(frameEnd - frameStart) / 1e6;
    samples.push(elapsedMs);
    if (samples.length > 600) samples.shift();
    if (elapsedMs > budget) dropped += 1;
  };

  out.on('resize', () => {
    previous = null;
  });

  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', (buffer: Buffer) => {
      const key = buffer.toString();
      if (key === 'q' || key === '\u0003') {
        process.exit(0);
      }
      if (key === '\t' || key === ']') {
        const capacity = computeLayout(out.columns ?? 100, out.rows ?? 30).capacity;
        const pages = pagesForCapacity(panels.length, capacity);
        page = (page + 1) % pages;
        previous = null;
      }
      if (key === 'p') {
        plain = !plain;
        previous = null;
      }
    });
  }

  process.on('exit', () => {
    out.write(CONTROL.showCursor + CONTROL.mainScreen + CONTROL.reset);
  });

  timer = setInterval(tick, Math.max(16, Math.round(1000 / Math.max(1, options.fps))));
  tick();

  return new Promise<LoopStats>((resolve) => {
    process.on('exit', () => resolve(finish()));
    process.on('SIGINT', () => {
      const stats = finish();
      resolve(stats);
      process.exit(0);
    });
  });
}
