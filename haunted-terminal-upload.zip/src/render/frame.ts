import { duration } from '../util/format';
import { DEFAULT_THEME, type Theme } from '../render/themes';
import { ghostIntensity, parseCellKey, type GhostMap } from '../effects/burnin';
import { isHidden, type FlickerWindow } from '../effects/flicker';
import { revealText } from '../effects/typewriter';
import { whisperFor } from '../effects/whisper';
import type { PanelData, PanelState } from '../panels/types';
import { truncate } from '../util/format';
import { computeLayout, pagesForCapacity, type Rect } from './layout';
import { createScreen, drawBox, writeText, type Screen } from './screen';

export type FrameInput = {
  width: number;
  height: number;
  now: number;
  startedAt: number;
  panels: PanelData[];
  page: number;
  plain: boolean;
  flicker: FlickerWindow[];
  ghosts: GhostMap;
  theme?: Theme;
};

const MASTHEAD = ' HAUNTED TERMINAL ';

function stateColor(state: PanelState, theme: Theme): string {
  switch (state) {
    case 'alarm':
      return theme.blood;
    case 'watch':
      return theme.candle;
    case 'idle':
      return theme.ash;
    case 'nominal':
    default:
      return theme.phosphor;
  }
}

function paintGhosts(screen: Screen, ghosts: GhostMap, now: number, theme: Theme): void {
  for (const [key, ghost] of ghosts) {
    const position = parseCellKey(key);
    if (!position) continue;
    const intensity = ghostIntensity(ghost, now);
    if (intensity <= 0) continue;
    const sgr = intensity > 0.55 ? theme.phosphorDim : theme.ghost;
    writeText(screen, position.x, position.y, ghost.ch, sgr, 1);
  }
}

function drawPanel(screen: Screen, rect: Rect, data: PanelData, input: FrameInput, hidden: boolean, theme: Theme): void {
  const dimmed = hidden || input.plain;
  const borderSgr = dimmed ? theme.phosphorDim : stateColor(data.state, theme);
  const titleSgr = dimmed ? theme.phosphorDim : theme.bone;
  const elapsed = input.now - input.startedAt;

  const title = input.plain ? data.title : revealText(data.title, elapsed, 800);
  drawBox(screen, rect, title, borderSgr, titleSgr);

  const bodyWidth = Math.max(1, rect.w - 4);
  const whisperRow = data.whisper && !input.plain && rect.h >= 6 ? 1 : 0;
  const bodyRows = Math.max(0, rect.h - 2 - whisperRow);

  for (let index = 0; index < data.lines.length && index < bodyRows; index += 1) {
    const y = rect.y + 1 + index;
    writeText(screen, rect.x + 2, y, truncate(data.lines[index], bodyWidth), stateColor(data.state, theme), bodyWidth);
  }

  if (whisperRow === 1 && data.whisper) {
    const y = rect.y + rect.h - 2;
    writeText(screen, rect.x + 2, y, truncate(data.whisper, bodyWidth), theme.ghost, bodyWidth);
  }
}

/**
 * Pure frame composition: same inputs, same screen. Values are always written
 * after the flicker decision, so a flicker can dim a border but can never hide
 * a number (requirement R3).
 */
export function renderFrame(input: FrameInput): Screen {
  const { width, height, now, panels, plain, flicker, ghosts } = input;
  const theme = input.theme ?? DEFAULT_THEME;
  const screen = createScreen(width, height, theme.phosphorDim);
  const layout = computeLayout(width, height);

  if (!plain) paintGhosts(screen, ghosts, now, theme);

  const hidden = !plain && isHidden(flicker, now);
  const elapsed = now - input.startedAt;

  const masthead = plain ? MASTHEAD : revealText(MASTHEAD, elapsed, 900);
  writeText(screen, 0, 0, masthead, theme.phosphor, width);

  const pages = pagesForCapacity(panels.length, layout.capacity);
  const clock = new Date(now).toISOString().slice(11, 19);
  const right = `pg ${input.page + 1}/${pages}  ${clock}Z `;
  if (width > masthead.length + right.length) {
    writeText(screen, width - right.length, 0, right, theme.phosphorDim, right.length);
  }

  const start = input.page * layout.capacity;
  const visible = panels.slice(start, start + layout.capacity);
  for (let index = 0; index < visible.length; index += 1) {
    const rect = layout.rects[index];
    const data = visible[index];
    if (!rect || !data) continue;
    drawPanel(screen, rect, data, input, hidden, theme);
  }

  const loudest = visible.find((panel) => panel.state === 'alarm') ?? visible[0];
  const footerState: PanelState = loudest?.state ?? 'nominal';
  const hint = plain
    ? ' --plain  atmosphere disabled'
    : ` [q] quit  [tab] page  [p] plain  ${whisperFor(footerState, Math.floor(now / 4000))}`;
  writeText(screen, 0, height - 1, truncate(hint, width), theme.ash, width);

  return screen;
}

export function frameAgeLabel(ms: number): string {
  return duration(ms / 1000);
}
