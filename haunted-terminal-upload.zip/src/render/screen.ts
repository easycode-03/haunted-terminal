import { PALETTE } from './ansi';
import type { Rect } from './layout';

export type Cell = { ch: string; sgr: string };
export type Screen = { width: number; height: number; cells: Cell[][] };

export function createScreen(width: number, height: number, baseSgr: string = PALETTE.phosphorDim): Screen {
  const cells: Cell[][] = [];
  for (let y = 0; y < height; y += 1) {
    const row: Cell[] = [];
    for (let x = 0; x < width; x += 1) row.push({ ch: ' ', sgr: baseSgr });
    cells.push(row);
  }
  return { width, height, cells };
}

export function cloneScreen(screen: Screen): Screen {
  return {
    width: screen.width,
    height: screen.height,
    cells: screen.cells.map((row) => row.map((cell) => ({ ch: cell.ch, sgr: cell.sgr }))),
  };
}

export function inBounds(screen: Screen, x: number, y: number): boolean {
  return x >= 0 && y >= 0 && x < screen.width && y < screen.height;
}

export function setCell(screen: Screen, x: number, y: number, ch: string, sgr: string): void {
  if (!inBounds(screen, x, y)) return;
  screen.cells[y][x] = { ch, sgr };
}

export function getCell(screen: Screen, x: number, y: number): Cell | undefined {
  if (!inBounds(screen, x, y)) return undefined;
  return screen.cells[y][x];
}

/**
 * Writes text at (x, y), clipped to `maxWidth` cells and to the screen bounds.
 * One code point occupies one cell: this dashboard is ASCII plus box drawing,
 * so full-width characters are out of scope by design.
 */
export function writeText(
  screen: Screen,
  x: number,
  y: number,
  text: string,
  sgr: string,
  maxWidth = Number.POSITIVE_INFINITY,
): number {
  if (y < 0 || y >= screen.height) return 0;
  const chars = Array.from(text);
  let written = 0;
  for (let index = 0; index < chars.length; index += 1) {
    if (written >= maxWidth) break;
    const cellX = x + index;
    if (cellX < 0) continue;
    if (cellX >= screen.width) break;
    screen.cells[y][cellX] = { ch: chars[index], sgr };
    written += 1;
  }
  return written;
}

export function fillRect(screen: Screen, rect: Rect, ch: string, sgr: string): void {
  for (let y = rect.y; y < rect.y + rect.h; y += 1) {
    for (let x = rect.x; x < rect.x + rect.w; x += 1) setCell(screen, x, y, ch, sgr);
  }
}

/** Draws a single-line box. Degenerates gracefully for 1-wide or 1-tall rects. */
export function drawBox(screen: Screen, rect: Rect, title: string, borderSgr: string, titleSgr: string): void {
  const { x, y, w, h } = rect;
  if (w < 2 || h < 1) return;
  const right = x + w - 1;
  const bottom = y + h - 1;

  writeText(screen, x, y, '┌' + '─'.repeat(Math.max(0, w - 2)) + '┐', borderSgr, w);
  if (h > 1) {
    for (let row = y + 1; row < bottom; row += 1) {
      writeText(screen, x, row, '│', borderSgr, 1);
      writeText(screen, right, row, '│', borderSgr, 1);
    }
    writeText(screen, x, bottom, '└' + '─'.repeat(Math.max(0, w - 2)) + '┘', borderSgr, w);
  }

  if (title.length > 0 && w > 4) {
    const label = ` ${title} `;
    writeText(screen, x + 1, y, label, titleSgr, w - 2);
  }
}

export function renderToPlainText(screen: Screen): string {
  return screen.cells.map((row) => row.map((cell) => cell.ch).join('')).join('\n');
}
