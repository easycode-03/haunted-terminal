import { moveTo } from './ansi';
import { cloneScreen, type Screen } from './screen';

export type Change = { x: number; y: number; ch: string; sgr: string };

/**
 * Computes the cells that differ between two frames. This is the whole reason
 * the dashboard does not tear on slow terminals: we never repaint the screen,
 * we only ship the SGR runs that actually moved.
 */
export function changes(previous: Screen, next: Screen): Change[] {
  if (previous.width !== next.width || previous.height !== next.height) {
    throw new Error('frame size mismatch: refusing to diff different geometries');
  }
  const out: Change[] = [];
  for (let y = 0; y < next.height; y += 1) {
    for (let x = 0; x < next.width; x += 1) {
      const before = previous.cells[y][x];
      const after = next.cells[y][x];
      if (before.ch !== after.ch || before.sgr !== after.sgr) {
        out.push({ x, y, ch: after.ch, sgr: after.sgr });
      }
    }
  }
  return out;
}

export function applyChanges(screen: Screen, list: Change[]): Screen {
  const next = cloneScreen(screen);
  for (const change of list) {
    if (change.y < 0 || change.y >= next.height) continue;
    if (change.x < 0 || change.x >= next.width) continue;
    next.cells[change.y][change.x] = { ch: change.ch, sgr: change.sgr };
  }
  return next;
}

/**
 * Serialises changes into escape sequences, collapsing contiguous cells in the
 * same row into a single write and only re-emitting colour when it changes.
 */
export function serialize(list: Change[]): string {
  if (list.length === 0) return '';
  const sorted = [...list].sort((a, b) => a.y - b.y || a.x - b.x);
  let out = '';
  let pending = '';
  let cursorX = -1;
  let cursorY = -1;
  let cursorSgr = '';

  const flush = (): void => {
    if (pending.length > 0) {
      out += pending;
      pending = '';
    }
  };

  for (const change of sorted) {
    if (change.y !== cursorY || change.x !== cursorX) {
      flush();
      out += moveTo(change.x, change.y);
      cursorY = change.y;
      cursorX = change.x;
    }
    if (change.sgr !== cursorSgr) {
      flush();
      out += change.sgr;
      cursorSgr = change.sgr;
    }
    pending += change.ch;
    cursorX = change.x + 1;
  }

  flush();
  return out;
}
