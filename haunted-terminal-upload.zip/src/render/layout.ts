/**
 * Panel geometry. Pure math, verified by property tests across 40..300 columns
 * and 12..60 rows (requirement R2 in .kiro/specs/panel-grid/requirements.md).
 */

export type Rect = { x: number; y: number; w: number; h: number };

export type Layout = {
  width: number;
  height: number;
  cols: number;
  rows: number;
  capacity: number;
  rects: Rect[];
  header: Rect;
  footer: Rect;
};

export const PANEL_COUNT = 4;
export const MIN_PANEL_W = 18;
export const MIN_PANEL_H = 5;
export const GAP = 1;
export const MAX_COLS = 2;
export const MAX_ROWS = 2;

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function computeLayout(width: number, height: number): Layout {
  const screenW = Math.max(1, Math.trunc(width));
  const screenH = Math.max(1, Math.trunc(height));

  const header: Rect = { x: 0, y: 0, w: screenW, h: 1 };
  const footer: Rect = { x: 0, y: screenH - 1, w: screenW, h: 1 };

  const contentY = 1;
  const contentH = Math.max(0, screenH - 2);

  const cols = clamp(Math.floor((screenW + GAP) / (MIN_PANEL_W + GAP)), 1, MAX_COLS);
  const rows = clamp(Math.floor((contentH + GAP) / (MIN_PANEL_H + GAP)), 1, MAX_ROWS);
  const capacity = cols * rows;

  const cellW = Math.floor((screenW - (cols - 1) * GAP) / cols);
  const cellH = Math.floor((contentH - (rows - 1) * GAP) / rows);

  const rects: Rect[] = [];
  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      const x = col * (cellW + GAP);
      const y = contentY + row * (cellH + GAP);
      // The last column and the last row absorb the rounding remainder so the
      // grid always ends exactly at the screen edge.
      const w = col === cols - 1 ? screenW - x : cellW;
      const h = row === rows - 1 ? contentY + contentH - y : cellH;
      rects.push({ x, y, w: Math.max(0, w), h: Math.max(0, h) });
    }
  }

  return { width: screenW, height: screenH, cols, rows, capacity, rects, header, footer };
}

export function pagesForCapacity(panelCount: number, capacity: number): number {
  const safe = Math.max(1, capacity);
  return Math.max(1, Math.ceil(panelCount / safe));
}
