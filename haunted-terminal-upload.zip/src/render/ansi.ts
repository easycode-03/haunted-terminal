/**
 * Escape sequences and the ANSI palette. Every colour the dashboard can paint
 * lives here, which is what the steering rule `ansi-style.md` is about.
 */

export const ESC = '\u001b[';

export const CONTROL = {
  reset: `${ESC}0m`,
  hideCursor: `${ESC}?25l`,
  showCursor: `${ESC}?25h`,
  altScreen: `${ESC}?1049h`,
  mainScreen: `${ESC}?1049l`,
  clear: `${ESC}2J`,
  home: `${ESC}H`,
} as const;

export function fg(index: number): string {
  return `${ESC}38;5;${index}m`;
}

export function moveTo(x: number, y: number): string {
  return `${ESC}${y + 1};${x + 1}H`;
}

/** 256-colour indices. Kept flat and boring on purpose: slow terminals tear. */
export const PALETTE = {
  phosphor: fg(82),
  phosphorDim: fg(22),
  ghost: fg(28),
  bone: fg(250),
  blood: fg(160),
  ash: fg(240),
  candle: fg(220),
} as const;
